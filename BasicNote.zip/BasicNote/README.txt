--------------
|BasicNote CE|
--------------
version 1.0.0
released July 26th, 2018

A powerful text-editor, programmed completely in TI-Basic.
Created by Michael2_3B for the TI-84+ CE (over the course of 2 very long years :P)

If you have a bug report, comments, or questions, please post in the thread: cemete.ch/t14483


[[About]]
BasicNote is an advanced text-editor written completely in the calculator's TI-Basic language.
It is perfect for when you need to jot down a quick note, or even if you want to have fun creating several pages of notes.
You are free to use this program however you like, though I advise against using it for cheating.

BasicNote has a variety of features that you could expect from a text editor,
but that you probably weren't expecting from a TI-Basic program!
These features include (but are not limited to):
-text selection
-copying
-pasting
-word wrapping and line breaks
-special characters
-auto saving
-error detection


[[Installation and Execution]]
Send BNCE.8xg to your calculator using your favorite calc-2-computer cable and TI-Connect CE software.
Hit "prgm" and select BNOTECE from the list of programs.
Hit "enter"


[[Usage/Controls]]
This is kind of self-explanatory, but:
Use the buttons below the screen to use the functions displayed on the bottom of the screen.
Use the keypad to enter any text you like.

On the menu, you may  use the [del] button to delete a note you are hovering over.

The [2nd] and [alpha] key can be used to control the text mode you are in,
which will display an icon in the top right corner of the screen. These are:
(blank) - the text printed directly on the buttons
2 - the blue text printed on your calculator
A - the green text, in uppercase
a - lowercase

Other Accessible Functions:
Special Character Entry - Make sure you are in mode "2" and hit 0 (or catalog). Hit [clear] to exit this menu.
Start/Stop Text Selection - Make sure you are in mode "2" and hit + (or mem). Move the cursor around to select. You may also delete your entire selection if need be.
Copy - Make sure your mode is blank, and hit sto->. The text will be copied to the clipboard and deselected.
Paste - Make sure you are in mode "2", and hit sto-> (or rcl).


[[Version History]]
v1.0.0, released 07/26/18
  -initial release


[[Additional Notes]]
This program overwrites several variables, the majority of which include:
Str2, Str3, Str5, Str6, Str7, Str8, Str9
L1, L2, L3
All real variables

Never, ever, delete or tamper with the lists BNOTE, BNS0 thru BNS8, BNER, or BMEM.
Tampering with these could result in loss of your data.

In order to make sure your notes are completely safe, always hit the exit button on the main menu before quitting
so that your note is compressed into its very own list.
Unexpected quitting, either because of a bug or pressing the ON key, will only leave the most recent save in Str6.

[[Legal]]
Copyright 2018 Michael2_3B

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.